<?php return array('dependencies' => array(), 'version' => '2ed2c068682645c3aa57');
